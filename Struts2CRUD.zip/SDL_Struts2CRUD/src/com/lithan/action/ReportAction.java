package com.lithan.action;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lithan.bean.EmpBean;
import com.lithan.dao.EmpDao;
import com.opensymphony.xwork2.ActionSupport;

public class ReportAction extends ActionSupport{
	
	//Create object to call DAO's methods
	EmpDao e_dao;
	
	ResultSet rs=null;
	
	//Represent one employee
	EmpBean bean = null; 
	
	//Represent lists of employee
	List<EmpBean> beanList = null;
	
	//To control data exist or not
	private boolean Data = false;

	@Override
	public String execute() throws Exception {
		
		//Dao Object Creation
		e_dao=new EmpDao();
		
		//BeanList Object Creation
		beanList = new ArrayList<EmpBean>();
		
		// Get all emp data from report Method
		rs=e_dao.report();
		
		//Loop ResultSet Data
		int srNo=1;
		while(rs.next()) {
			
			String emp_name=rs.getString("uname");
			String emp_email=rs.getString("uemail");
			String emp_pass=rs.getString("upass").replaceAll("(?s).", "*");
			String emp_deg=rs.getString("udeg");
			
			System.out.println("Employee data from database "+emp_name+", "+emp_email+", "+emp_pass+", "+emp_deg);
			
			//Object Creation
			bean=new EmpBean();
			bean.setSrNo(srNo);
			bean.setUname(emp_name);
			bean.setUemail(emp_email);
			bean.setUpass(emp_pass);
			bean.setUdeg(emp_deg);
			
			System.out.println("Bean Created Successfully");
			//Emp bean add to bean lists
			beanList.add(bean);
			
			System.out.println("Bean added Successfully to bean list");
			
		srNo++;	
		}//end while
		
		if (srNo > 1) {
			Data = true; 
		}else{
			Data = false; 
		}
		
		
		return "REPORT";
	}


	public boolean isData() {
		return Data;
	}


	public void setData(boolean data) {
		Data = data;
	}


	public List<EmpBean> getBeanList() {
		return beanList;
	}

	public void setBeanList(List<EmpBean> beanList) {
		this.beanList = beanList;
	}

}
