package com.lithan.action;

public class UpdateAction {

}
