package com.lithan.action;

import com.lithan.dao.EmpDao;
import com.opensymphony.xwork2.ActionSupport;

public class RegisterAction extends ActionSupport{
	
	//To get data from "Form"
	private String uname;
	private String uemail;
	private String upass;
	private String udeg;
	
	//To show success or error message
	private String msg;
	
	//To check the result from DAO
	private int insert_result;
	
	//Create object to call DAO's methods
	EmpDao e_dao;

	@Override
	public String execute() throws Exception {
		
		
		//Get data from "Form"-textbox
		System.out.println("UName is "+uname);
		System.out.println("User Email is "+uemail);
		System.out.println("User Password is "+upass);
		System.out.println("User Designation is "+udeg);
		
		
		//create EMP object
		e_dao=new EmpDao();
		
		//Call the register method
		insert_result=e_dao.registerUser(uname, uemail, upass, udeg);
		System.out.println("Insert Result  is "+insert_result);
		
		if(insert_result>0) {
			msg="Your Registeration is Successful";
		}else {
			msg="Error";
		}
		
		return "REGISTER";
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUemail() {
		return uemail;
	}

	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	
	public String getUpass() {
		return upass;
	}

	public void setUpass(String upass) {
		this.upass = upass;
	}

	public String getUdeg() {
		return udeg;
	}

	public void setUdeg(String udeg) {
		this.udeg = udeg;
	}

	public int getInsert_result() {
		return insert_result;
	}

	public void setInsert_result(int insert_result) {
		this.insert_result = insert_result;
	}
}
