package com.lithan.action;

public class DeleteAction {

}
